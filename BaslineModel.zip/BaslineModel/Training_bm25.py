import math
from porter2 import stem
from datetime import datetime
start=datetime.now()

def avg_doc_len(coll):
    tot_dl = 0
    for id, doc in coll.get_docs().items():
        tot_dl = tot_dl + doc.get_doc_len()
    return tot_dl / coll.get_num_docs()


def w4(coll, ben, theta):
    T = {}
    # select T from positive documents and r(tk)
    for id, doc in coll.get_docs().items():
        if ben[id] > 0:
            for term, freq in doc.terms.items():
                try:
                    T[term] += 1
                except KeyError:
                    T[term] = 1
    # calculate n(tk)
    ntk = {}
    for id, doc in coll.get_docs().items():
        for term in doc.get_term_list():
            try:
                ntk[term] += 1
            except KeyError:
                ntk[term] = 1

    # calculate N and R

    No_docs = coll.get_num_docs()
    R = 0
    for id, fre in ben.items():
        if ben[id] > 0:
            R += 1
    temp = {}
    for id, rtk in T.items():
        T[id] = ((rtk+0.5 ) / (R - rtk +0.5)) / ((ntk[id] - rtk +0.5) / (No_docs - ntk[id] - R + rtk + 0.5 ))
       # T[id] =math.log(((rtk+0.5 ) * (No_docs - ntk[id] - R + rtk + 0.5 ) )/ ((ntk[id] - rtk +0.5) *(R - rtk +0.5) ))
        #T[id] = math.log(1.0 / ((ntk[id] - rtk +0.5) *(R - rtk +0.5) ))/ ((rtk+0.5 ) * (No_docs - ntk[id] - R + rtk + 0.5 )),2)

        # calculate the mean of w4 weights.
    meanW4 = 0
    for id, rtk in T.items():
        meanW4 += rtk
    if len(T) != 0:
        meanW4 = meanW4 / len(T)

    # Features selection
    Features = {t: r for t, r in T.items() if r > meanW4 + theta}
    return Features

if __name__ == "__main__":

    import sys
    import os
    import coll
    import df

    # PYTHON NOTE: it would be more elegant to create a class that
    # represents the index, and which stores the DF dictionary and other
    # statistics

    i = 100
    while (i < 150):
        i = i + 1
        coll_fname = ".\Training_set\Training" + str(i)
        stopwords_f = open('common-english-words.txt', 'r')
        stop_words = stopwords_f.read().split(',')
        stopwords_f.close()
        coll_ = coll.parse_rcv_coll(coll_fname, stop_words)

        os.chdir('..')
        os.chdir('..')

        benFile = open('PTraining_benchmark' + str(i) + '.txt')

        file_ = benFile.readlines()

        ben = {}
        for line in file_:
            line = line.strip()
            lineList = line.split()
            ben[lineList[1]] = float(lineList[2])

        benFile.close()
        theta = 3.5
        bm25_weights = w4(coll_, ben, theta)

        wFile = open('Model_w4_R' + str(i) + '.dat', 'w')
        for (k, v) in sorted(bm25_weights.items(), key=lambda x: x[1], reverse=True):
            wFile.write(k + ' ' + str(v) + '\n')
        wFile.close()

print( datetime.now()-start )