import math
from porter2 import stem
from datetime import datetime
start=datetime.now()

def BM25Testing(coll, features):
    ranks = {}
    for id, doc in coll.get_docs().items():

        Rank = 0
        for term in features.keys():
            if term in doc.get_term_list():
                try:
                    ranks[id] += features[term]
                except KeyError:
                    ranks[id] = features[term]
    return ranks


if __name__ == "__main__":

    import sys
    import os
    import coll
    import df

    j=101
    count = 1
    while j<=150:

        coll_fname = ".\Training_set\Training"+ str(j)

        # pre-processing documents
        stopwords_f = open('common-english-words.txt', 'r')
        stop_words = stopwords_f.read().split(',')
        stopwords_f.close()
        coll_ = coll.parse_rcv_coll(coll_fname, stop_words)

        # get features
        os.chdir('..')
        os.chdir('..')
        featureFile = open('Model_w4_R'+ str(j) + '.dat')
        file_ = featureFile.readlines()
        features = {}
        for line in file_:
            line = line.strip()
            lineList = line.split()
            features[lineList[0]] = float(lineList[1])
        featureFile.close()

        # obtain ranks for all documents
        ranks = BM25Testing(coll_, features)

        wFile = open('result' + str(count) + '.dat', 'w')
        for (d, v) in sorted(ranks.items(), key=lambda x: x[1], reverse=True):
            wFile.write(d + ' ' + '1' + ' ' + str(v) + '\n')
        wFile.close()

        j=j+1
        count= count+1


print( datetime.now()-start )